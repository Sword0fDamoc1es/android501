package com.example.temperatureconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    SeekBar sbCelsius;
    SeekBar sbFahrenheit;
    TextView tvCelsius;
    TextView tvFahrenheit;
    TextView tvCelsiusValue;
    TextView tvFahrenheitValue;
    TextView tvMessage;

    double celsiusValue = 0.0;
    double fahrenheitValue = 32.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sbCelsius = (SeekBar) findViewById(R.id.sbCelsius);
        sbFahrenheit = (SeekBar) findViewById(R.id.sbFahrenheit);
        tvCelsius = (TextView) findViewById(R.id.tvCelsius);
        tvFahrenheit = (TextView) findViewById(R.id.tvFahrenheit);
        tvCelsiusValue = (TextView) findViewById(R.id.tvCelsiusValue);
        tvFahrenheitValue = (TextView) findViewById(R.id.tvFahrenheitValue);
        tvMessage = (TextView) findViewById(R.id.tvMessage);

        sbCelsius.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                // compute fahrenheit value
                celsiusValue = (double) progress;
                fahrenheitValue = celsiusValue * 9 / 5 + 32;
                // update celsius textview
                tvCelsiusValue.setText(String.format("%.2f", celsiusValue));
                // update fahrenheit seekbar
                sbFahrenheit.setProgress((int) fahrenheitValue);
                // update fahrenheit textview
                tvFahrenheitValue.setText(String.format("%.2f", fahrenheitValue));
                // change bottom message
                if (progress < 20) {
                    tvMessage.setText(getString(R.string.message_cold));
                } else if (progress > 20){
                    tvMessage.setText(getString(R.string.message_warm));
                } else {
                    tvMessage.setText(getString(R.string.message_perfect));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        sbFahrenheit.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                // compute celsius value
                fahrenheitValue = (double) progress;
                celsiusValue = (fahrenheitValue - 32) * 5 / 9;
                if (progress < 32) {
                    sbFahrenheit.setProgress(32);
                } else {
                    // update fahrenheit textview
                    tvFahrenheitValue.setText(String.format("%.2f", fahrenheitValue));
                    // update celsius seekbar
                    sbCelsius.setProgress((int) celsiusValue);
                    // update celsius textview
                    tvCelsiusValue.setText(String.format("%.2f", celsiusValue));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
}