package com.example.lifecyclelogevents;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button button;
    EditText editText;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.button);
        editText = (EditText) findViewById(R.id.editText);
        textView = (TextView) findViewById(R.id.textView);
        Log.d("CATLOG","onCreate start!");

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.setText("Edit:Hello");
                textView.setText("Text:Hello");
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("CATLOG","onStart start!");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("CATLOG","onRestart start!");

    }

    @Override
    protected void onResume() {
        super.onResume();

        Log.d("CATLOG","onResume start!");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("CATLOG","onPause start!");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("CATLOG","onStop start!");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("CATLOG","onDestroy start!");
    }
}