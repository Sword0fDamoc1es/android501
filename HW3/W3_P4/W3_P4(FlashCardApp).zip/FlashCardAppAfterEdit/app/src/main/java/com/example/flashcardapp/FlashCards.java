package com.example.flashcardapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class FlashCards extends AppCompatActivity{

    private Button btnGenerateProblems;
    private Button btnSubmit;
    private TextView tvWelcomeUser;
    private EditText edtInputAnswer;
    private TextView tvFirstNumber;
    private TextView tvSecondNumber;
    private TextView tvOperator;

    private boolean reachedEnd;
    private ArrayList<String> problemResults;
    private int questionNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flashcards);
        /**
         * reachedEnd = A boolean that will record whether or not the "btnGenerateProblems" should be clickable
         * questionNumber = An int that records what question is currently being answered so that we may know
         *      once 10 questions have been answered
         * problemResults = An arraylist that records whether each question/answer was correct or incorrect
         *      i.e: (Correct, Correct, Incorrect, Incorrect, Incorrect, Correct, Correct, Correct, Correct, Correct)
         */
        reachedEnd = true;
        problemResults = new ArrayList<String>();
        questionNumber = 1;

        // Instantiating the variables
        btnGenerateProblems = (Button) findViewById(R.id.btnGenerateProblems);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        tvWelcomeUser = (TextView) findViewById(R.id.tvWelcomeUser);
        edtInputAnswer = (EditText) findViewById(R.id.edtInputAnswer);
        tvFirstNumber = (TextView) findViewById(R.id.tvFirstNumber);
        tvSecondNumber = (TextView) findViewById(R.id.tvSecondNumber);
        tvOperator = (TextView) findViewById(R.id.tvOperator);



        // Make the TextViews for the numbers and operator invisible at startup so that the welcome message can be displayed
        tvFirstNumber.setVisibility(View.INVISIBLE);
        tvSecondNumber.setVisibility(View.INVISIBLE);
        tvOperator.setVisibility(View.INVISIBLE);

        // Display username from the bundle we got from MainActivity
        Bundle bundle = getIntent().getExtras();
        tvWelcomeUser.setText("Welcome " + bundle.getString("username"));

        /**
         * If all 10 questions have been answered then allow for "btnGenerateProblems" to be clickable
         * Otherwise "btnGenerateProblems" will be unclickable
         */
        if(reachedEnd)
            btnGenerateProblems.setClickable(true);
        else
            btnGenerateProblems.setClickable(false);

        btnSubmit.setClickable(false);

        btnGenerateProblems.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               /**
                * On startup of click we make "btnGenerateProblems" unclickable so that the user cannot restart halfway through
                * Make "reachedEnd" false since we just initialized the 10 questions
                * Make "btnSubmit" clickable so that the user may submit their answer
                */
               btnGenerateProblems.setClickable(false);
               reachedEnd = false;
               btnSubmit.setClickable(true);
               problemResults = new ArrayList<String>();

               // Turnoff visibility for the welcome message and turn on visibility for the numbers and operator
               tvWelcomeUser.setVisibility(View.INVISIBLE);
               tvFirstNumber.setVisibility(View.VISIBLE);
               tvSecondNumber.setVisibility(View.VISIBLE);
               tvOperator.setVisibility(View.VISIBLE);

               // Call helper function "createNewProblem" to create a new math problem
               createNewProblem(tvFirstNumber, tvSecondNumber, tvOperator);
           }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /**
                 * Check to see whether the inputted answer is correct or incorrect by calling
                 *      the helper function "solveProblem"
                 */
                if (Integer.parseInt(edtInputAnswer.getText().toString()) == solveProblem(tvFirstNumber,
                        tvSecondNumber, tvOperator))
                    problemResults.add("Correct");
                else
                    problemResults.add("Incorrect");

                /**
                 * Set InputText back to "" and create a new math problem if the user hasn't answered 10 yet
                 * If the user has answered 10 questions then disable the "btnSubmit" and enable the "btnGenerateProblems"
                 *      Send a toast with the number of problems that were answered correctly
                 */
                edtInputAnswer.setText("");
                if(questionNumber < 10) {
                    questionNumber += 1;
                    createNewProblem(tvFirstNumber, tvSecondNumber, tvOperator);
                }
                else {
                    btnSubmit.setClickable(false);
                    questionNumber = 1;
                    btnGenerateProblems.setClickable(true);
                    reachedEnd = true;

                    Context context = getApplicationContext();
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(context, amountCorrect(problemResults), duration);
                    toast.show();
                }
            }
        });

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("firstNum", tvFirstNumber.getText().toString());
        outState.putString("secondNum", tvSecondNumber.getText().toString());
        outState.putString("op", tvOperator.getText().toString());
        outState.putStringArrayList("results", problemResults);
        outState.putBoolean("end", reachedEnd);
        outState.putInt("question", questionNumber);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        tvFirstNumber.setText(savedInstanceState.getString("firstNum"));
        tvSecondNumber.setText(savedInstanceState.getString("secondNum"));
        tvOperator.setText(savedInstanceState.getString("op"));
        problemResults = savedInstanceState.getStringArrayList("results");
        reachedEnd = savedInstanceState.getBoolean("end");
        questionNumber = savedInstanceState.getInt("question");
        if(reachedEnd == false) {
            btnGenerateProblems.setClickable(false);
            btnSubmit.setClickable(true);

            // Turnoff visibility for the welcome message and turn on visibility for the numbers and operator
            tvWelcomeUser.setVisibility(View.INVISIBLE);
            tvFirstNumber.setVisibility(View.VISIBLE);
            tvSecondNumber.setVisibility(View.VISIBLE);
            tvOperator.setVisibility(View.VISIBLE);
        }
    }

    /**
     * A helper method that generates a plus or minus symbol
     * @return "+" or "-"
     */
    private String addOrSubtract() {
        double temp = Math.random();
        if(temp>0.5)
            return "+";
        else
            return "-";
    }

    /**
     * A helper method that returns a string of a random number within the given range
     * @param range - An int number of the max number that the random number should reach (max-cap)
     * @return String of a random integer
     */
    private String createRandomNumberString(int range) {
        int temp = (int) (Math.random()*range)+1;
        return String.valueOf(temp);
    }

    /**
     * A helper method that creates a new math problem with the provided TextViews
     * @param firstNum
     * @param secondNum
     * @param op
     */
    private void createNewProblem(TextView firstNum, TextView secondNum, TextView op) {
        firstNum.setText(createRandomNumberString(99));
        secondNum.setText(createRandomNumberString(20));
        op.setText(addOrSubtract());
    }

    /**
     * A helper method that solves a math problem with the provided TextViews
     * @param firstNum
     * @param secondNum
     * @param op
     * @return Integer of the correct solution of the math problem
     */
    private int solveProblem(TextView firstNum, TextView secondNum, TextView op) {
        if(op.getText().toString().equals("+"))
            return Integer.parseInt(firstNum.getText().toString()) + Integer.parseInt(secondNum.getText().toString());
        else
            return Integer.parseInt(firstNum.getText().toString()) - Integer.parseInt(secondNum.getText().toString());
    }

    /**
     * A helper method that returns a string of how many questions the user got correct
     * @param results
     * @return String with the number of questions the user answered correctly
     *      i.e: "9/10", "2/10", etc.
     */
    private String amountCorrect(ArrayList<String> results) {
        int correct = 0;
        for(String item: results)
            if(item.equals("Correct"))
                correct+=1;
        return correct + "/10";
    }
}
