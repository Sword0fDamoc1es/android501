package com.example.flashcardapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // Hardcoded login info
    private final String username = "Joe";
    private final String password = "123abc";

    private EditText edtUsername;
    private EditText edtPassword;
    private Button btnLogin;
    private TextView tvError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Instantiating the variables
        edtUsername = (EditText) findViewById(R.id.edtUsername);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        tvError = (TextView) findViewById(R.id.tvError);

        // Hiding Error message (Error message pops up when user puts in wrong info)
        tvError.setVisibility(View.INVISIBLE);

        /**
         * inputUsername = The username that is currently in the username field
         * inputPassword = The password that is currently in the password field
         *
         * Checks if the username and password checkout, then proceeds to launch the next page (flashcards)
         *      along with a bundle that contains the user's username.
         * If username is incorrect then error message is displayed
         */
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String inputUsername = edtUsername.getText().toString();
                String inputPassword = edtPassword.getText().toString();
                if(inputUsername.equals(username) && inputPassword.equals(password)) {
                    Intent FlashCards = new Intent(getApplicationContext(), FlashCards.class );
                    FlashCards.putExtra("username", inputUsername);
                    startActivity(FlashCards);
                }
                else {
                    tvError.setVisibility(View.VISIBLE);
                }
            }
        });
    }
}