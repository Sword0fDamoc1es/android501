package com.example.flashlight;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Switch switchToggle;
    private LinearLayout LL_switch;
    private LinearLayout.LayoutParams LLP;
    private GestureDetectorCompat mGestureDetector;
    private SearchView sv_searchbar;

    boolean hasCameraFlash = false;
    boolean flashOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // gesture detector
        mGestureDetector = new GestureDetectorCompat(this, new GestureListener());

        // search bar
        sv_searchbar = (SearchView) findViewById(R.id.sv_searchbar);
        sv_searchbar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onQueryTextSubmit(String s) {
                if (s.equals("ON") || s.equals("on") || s.equals("On")) {
                    try {
                        flashLightOn();
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }
                else if (s.equals("OFF") || s.equals("off") || s.equals("Off")) {
                    try {
                        flashLightOff();
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    Toast.makeText(MainActivity.this, "Invalid Input !!!", Toast.LENGTH_SHORT).show();
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });

        // create switch
        switchToggle = new Switch(MainActivity.this);

        // find switch a view group
        LL_switch = (LinearLayout) findViewById(R.id.LL_switch);
        LLP = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT);
        LLP.weight = 1.0f;
        LLP.rightMargin = 30;
        switchToggle.setLayoutParams(LLP);
        LL_switch.addView(switchToggle);

        // link switch toggle to camera flashlight
        hasCameraFlash = getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
        switchToggle.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                if (switchToggle.isChecked()) {
                    try {
                        flashLightOn();
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    try {
                        flashLightOff();
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }



    private class GestureListener extends GestureDetector.SimpleOnGestureListener{
        @RequiresApi(api = Build.VERSION_CODES.M)
        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            float diffX = e2.getX() - e1.getX();
            float diffY = e2.getY() - e1.getY();
            if (Math.abs(diffY) > Math.abs(diffX)) {                        // up or down swipe
                if (Math.abs(diffY) > 200 && Math.abs(velocityY) > 100) {   // set threshold to avoid accidental touching
                    if (diffY > 0) { onFlingDown(); }
                    else { onFlingUp(); }
                }
            }
//            Toast.makeText(MainActivity.this, "Fling Detected", Toast.LENGTH_SHORT).show();
            return super.onFling(e1, e2, velocityX, velocityY);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void onFlingUp() {
        try {
            flashLightOn();
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void onFlingDown() {
        try {
            flashLightOff();
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        mGestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void flashLightOn() throws CameraAccessException{
        hasCameraFlash = getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
        if (hasCameraFlash){
            flashOn = true;
            switchToggle.setChecked(true);
            CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String camera_id = cameraManager.getCameraIdList()[0];
            cameraManager.setTorchMode(camera_id, true);
            Toast.makeText(this, "Flashlight is ON", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(MainActivity.this, "No flash available on this phone", Toast.LENGTH_LONG).show();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void flashLightOff() throws CameraAccessException{
        hasCameraFlash = getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
        if (hasCameraFlash){
            flashOn = false;
            switchToggle.setChecked(false);
            CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String camera_id = cameraManager.getCameraIdList()[0];
            cameraManager.setTorchMode(camera_id, false);
            Toast.makeText(this, "Flashlight is OFF", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(MainActivity.this, "No flash available on this phone", Toast.LENGTH_LONG).show();
        }
    }
}