package com.example.flingingmoney;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private TextView tvEurosLabel;
    private TextView tvYenLabel;
    private TextView tvPoundsLabel;
    private TextView tvPesosLabel;

    private TextView tvEuroAmount;
    private TextView tvYenAmount;
    private TextView tvPoundAmount;
    private TextView tvPesoAmount;

    private TextView tvDollarsLabel;
    private EditText edtDollarsAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvEurosLabel = (TextView) findViewById(R.id.tvEuroLabel);
        tvYenLabel = (TextView) findViewById(R.id.tvYenLabel);
        tvPoundsLabel = (TextView) findViewById(R.id.tvPoundsLabel);
        tvPesosLabel = (TextView) findViewById(R.id.tvPesoLabel);

        tvEuroAmount = (TextView) findViewById(R.id.tvEuroAmount);
        tvYenAmount = (TextView) findViewById(R.id.tvYenAmount);
        tvPoundAmount = (TextView) findViewById(R.id.tvPoundAmount);
        tvPesoAmount = (TextView) findViewById(R.id.tvPesoAmount);

        tvDollarsLabel = (TextView) findViewById(R.id.tvDollarsLabel);
        edtDollarsAmount = (EditText) findViewById(R.id.edtDollars);

        edtDollarsAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().equals("")){
                    double dollars = Double.valueOf(s.toString());
                    tvEuroAmount.setText(twoDecimalPlaces(currencyExchange(dollars, "Euro")));
                    tvYenAmount.setText(twoDecimalPlaces(currencyExchange(dollars, "Yen")));
                    tvPoundAmount.setText(twoDecimalPlaces(currencyExchange(dollars, "Pound")));
                    tvPesoAmount.setText(twoDecimalPlaces(currencyExchange(dollars, "Peso")));
                }
            }
        });
    }

    private double currencyExchange(double USDollar, String currency) {
        double amountToReturn = 0;
        switch(currency) {
            case "Yen":
                amountToReturn = USDollar*115.54;
                break;
            case "Euro":
                amountToReturn = USDollar*0.89;
                break;
            case "Pound":
                amountToReturn = USDollar*0.75;
                break;
            case "Peso":
                amountToReturn = USDollar*20.35;
                break;
            default:
                break;
        }
        return amountToReturn;
    }

    private String twoDecimalPlaces(double amount) {
        DecimalFormat df = new DecimalFormat("#.##");
        String result = df.format(amount);
        return result;
    }

}