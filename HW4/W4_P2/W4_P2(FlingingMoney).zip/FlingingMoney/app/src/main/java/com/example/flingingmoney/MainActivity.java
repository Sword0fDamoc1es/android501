package com.example.flingingmoney;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

import android.view.MotionEvent;
import android.view.GestureDetector;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener {

    private TextView tvEurosLabel;
    private TextView tvYenLabel;
    private TextView tvPoundsLabel;
    private TextView tvPesosLabel;

    private TextView tvEuroAmount;
    private TextView tvYenAmount;
    private TextView tvPoundAmount;
    private TextView tvPesoAmount;

    private TextView tvDollarsLabel;
    private EditText edtDollarsAmount;

    private GestureDetector GD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        GD = new GestureDetector(this, this);

        tvEurosLabel = (TextView) findViewById(R.id.tvEuroLabel);
        tvYenLabel = (TextView) findViewById(R.id.tvYenLabel);
        tvPoundsLabel = (TextView) findViewById(R.id.tvPoundsLabel);
        tvPesosLabel = (TextView) findViewById(R.id.tvPesoLabel);

        tvEuroAmount = (TextView) findViewById(R.id.tvEuroAmount);
        tvYenAmount = (TextView) findViewById(R.id.tvYenAmount);
        tvPoundAmount = (TextView) findViewById(R.id.tvPoundAmount);
        tvPesoAmount = (TextView) findViewById(R.id.tvPesoAmount);

        tvDollarsLabel = (TextView) findViewById(R.id.tvDollarsLabel);
        edtDollarsAmount = (EditText) findViewById(R.id.edtDollars);

        edtDollarsAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!s.toString().equals("")){
                    double dollars = Double.valueOf(s.toString());
                    tvEuroAmount.setText(twoDecimalPlaces(currencyExchange(dollars, "Euro")));
                    tvYenAmount.setText(twoDecimalPlaces(currencyExchange(dollars, "Yen")));
                    tvPoundAmount.setText(twoDecimalPlaces(currencyExchange(dollars, "Pound")));
                    tvPesoAmount.setText(twoDecimalPlaces(currencyExchange(dollars, "Peso")));
                }
            }
        });

    }

    private double currencyExchange(double USDollar, String currency) {
        double amountToReturn = 0;
        switch(currency) {
            case "Yen":
                amountToReturn = USDollar*115.54;
                break;
            case "Euro":
                amountToReturn = USDollar*0.89;
                break;
            case "Pound":
                amountToReturn = USDollar*0.75;
                break;
            case "Peso":
                amountToReturn = USDollar*20.35;
                break;
            default:
                break;
        }
        return amountToReturn;
    }

    private String twoDecimalPlaces(double amount) {
        DecimalFormat df = new DecimalFormat("#.##");
        String result = df.format(amount);
        return result;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        this.GD.onTouchEvent(event);               //Our GD will not automatically receive Android Framework Touch notifications.
        // Insert this line to consume the touch event locally by our GD,
        // IF YOU DON'T insert this before the return, our GD will not receive the event, and therefore won't do anything.
        return super.onTouchEvent(event);          // Do this last, why?
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        if (distanceY > 0) {
            // Scrolled upward
            double currentAmount = Double.valueOf(edtDollarsAmount.getText().toString());
            currentAmount += .1;
            DecimalFormat df = new DecimalFormat("#.##");
            String result = df.format(currentAmount);
            edtDollarsAmount.setText(result);
        }
        else if (distanceY < 0) {
            // Scrolled downard
            double currentAmount = Double.valueOf(edtDollarsAmount.getText().toString());
            if(currentAmount - .1 >= 0)
                currentAmount -= .1;
            DecimalFormat df = new DecimalFormat("#.##");
            String result = df.format(currentAmount);
            edtDollarsAmount.setText(result);
        }
        return true;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float velocityX, float velocityY) {
        if (velocityY > 0) {
            // Scrolled upward
            double currentAmount = Double.valueOf(edtDollarsAmount.getText().toString());
            currentAmount += 1;
            DecimalFormat df = new DecimalFormat("#.##");
            String result = df.format(currentAmount);
            edtDollarsAmount.setText(result);
        }
        else if (velocityY < 0) {
            // Scrolled downard
            double currentAmount = Double.valueOf(edtDollarsAmount.getText().toString());
            if(currentAmount - 1 >= 0)
                currentAmount -= 1;
            DecimalFormat df = new DecimalFormat("#.##");
            String result = df.format(currentAmount);
            edtDollarsAmount.setText(result);
        }
        return true;
    }

}