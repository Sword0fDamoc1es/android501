package com.example.accelerometermeasurements;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private SeekBar skbarThreshold;
    private TextView tvMin;
    private TextView tvMax;
    private int threshold;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvMin = (TextView) findViewById(R.id.tvMin);
        tvMax = (TextView) findViewById(R.id.tvMax);

        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        skbarThreshold = (SeekBar) findViewById(R.id.skbarThreshold);
        skbarThreshold.setMax(20);
        skbarThreshold.setProgress(3);
        threshold = 3;

        skbarThreshold.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // TODO Auto-generated method stub
                threshold = progress;
            }
        });
    }

    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION){
            float xMovement = sensorEvent.values[0];
            float yMovement = sensorEvent.values[1];
            float zMovement = sensorEvent.values[2];
            if(xMovement > threshold && yMovement > threshold && zMovement > threshold) {
                WebView myWebView = (WebView) findViewById(R.id.webview);
                myWebView.loadUrl("https://jumpingjaxfitness.files.wordpress.com/2010/07/dizziness.jpg \n");
                Toast.makeText( getApplicationContext(),"Shake detected", Toast.LENGTH_SHORT).show();
            }
            else if(xMovement > threshold && xMovement > yMovement && xMovement > zMovement) {
                WebView myWebView = (WebView) findViewById(R.id.webview);
                myWebView.loadUrl("https://www.ecosia.org/");
                Toast.makeText( getApplicationContext(),"Movement in X direction", Toast.LENGTH_SHORT).show();
            }
            else if(yMovement > threshold && yMovement > xMovement && yMovement > zMovement) {
                WebView myWebView = (WebView) findViewById(R.id.webview);
                myWebView.loadUrl("https://www.dogpile.com/");
                Toast.makeText( getApplicationContext(),"Movement in Y direction", Toast.LENGTH_SHORT).show();
            }
            else if(zMovement > threshold && zMovement > xMovement && zMovement > yMovement) {
                WebView myWebView = (WebView) findViewById(R.id.webview);
                myWebView.loadUrl("https://buzzsumo.com/");
                Toast.makeText( getApplicationContext(),"Movement in Z direction", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}