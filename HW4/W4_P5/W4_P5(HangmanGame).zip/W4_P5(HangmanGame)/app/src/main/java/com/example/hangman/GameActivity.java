package com.example.hangman;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class GameActivity extends AppCompatActivity {
    public String current;
    public String lettersUsed;
    public TextView wordtextView;
    public String answer;
    public ImageView imageView;
    public int errorCount;
    public int hintClicks;
    public TextView gameResult;
    public TextView tvHint;
    public Button newGame;
    public Button btnHint;
    public boolean gameState;
    public final String[] fruits = {"BANANA", "CHERRY", "LYCHEE", "ORANGE", "PAPAYA", "DURIAN", "MARULA"};
    public final String[] countries = {"RUSSIA", "KUWAIT", "FRANCE", "POLAND", "GREECE", "CANADA", "UGANDA"};
    public final String[] elements = {"CARBON", "OXYGEN", "SODIUM", "HELIUM", "COPPER", "SILVER", "INDIUM"};
    public ArrayList<List<String>> categoriesOfWords;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        categoriesOfWords = new ArrayList<List<String>>();
        categoriesOfWords.add(Arrays.asList(fruits));
        categoriesOfWords.add(Arrays.asList(countries));
        categoriesOfWords.add(Arrays.asList(elements));

        wordtextView = (TextView) findViewById(R.id.wordtextView);
        imageView = (ImageView) findViewById(R.id.imageView);
        gameResult = (TextView) findViewById(R.id.gameResult);
        tvHint = (TextView) findViewById(R.id.tvHint);
        newGame = (Button) findViewById(R.id.newGame);
        btnHint = (Button) findViewById(R.id.btnHint);

        gameState = true;
        gameResult.setVisibility(View.INVISIBLE);
        tvHint.setVisibility(View.INVISIBLE);
        // we will set answer. currently, this is a word.
        // But later, we need to 1. set several word set for different field: cars, countries, etc.
        // 2. get word from different set randomly. set the word as answer below.
        // for different sets of words, we can do "hint 1 method" on it, which gives a description.
        // I will finish hint 2 method. But hint button may need further discuss.
        answer = selectRandomWord(); // #TODO answer must fit the string length of chosen words.
        errorCount = 0;
        hintClicks = 0;
        lettersUsed = "";
        // # important! if we rotate, we need to store:
        // # 1. string in wordtextView, which is the process of ur game.
        // # 2. string current. which is what u've chosen(?? but once we click, it activates, does that need?)
        // # 3. errorCount.
        // # 4. ImageView path. what image we're using.
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        errorCount =  savedInstanceState.getInt("err");
        hintClicks =  savedInstanceState.getInt("hintClicks");
        // # important!
        // do changeImage immediately after we get the errorCount.
        changeImage();
        answer = savedInstanceState.getString("ans");
        wordtextView.setText(savedInstanceState.getString("wordtext"));
        gameState = savedInstanceState.getBoolean("state");

        gameResult.setVisibility(savedInstanceState.getInt("resultInt"));
        gameResult.setText(savedInstanceState.getString("resultText"));

        tvHint.setVisibility(savedInstanceState.getInt("tvHintVis"));
        tvHint.setText(savedInstanceState.getString("tvHintText"));

        lettersUsed = savedInstanceState.getString("lettersUsed");
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState, @NonNull PersistableBundle outPersistentState) {
        outState.putInt("err",errorCount);
        outState.putInt("hints",hintClicks);
        outState.putString("ans",answer);
        outState.putString("wordtext",wordtextView.getText().toString());
        outState.putBoolean("state",gameState);

        outState.putInt("resultInt",gameResult.getVisibility());
        outState.putString("resultText",gameResult.getText().toString());

        outState.putInt("tvHintVis",tvHint.getVisibility());
        outState.putString("tvHintText",tvHint.getText().toString());

        outState.putString("lettersUsed", lettersUsed);
        super.onSaveInstanceState(outState, outPersistentState);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putInt("err",errorCount);
        outState.putInt("hints",hintClicks);
        outState.putString("ans",answer);
        outState.putString("wordtext",wordtextView.getText().toString());
        outState.putBoolean("state",gameState);

        outState.putInt("resultInt",gameResult.getVisibility());
        outState.putString("resultText",gameResult.getText().toString());

        outState.putInt("tvHintVis",tvHint.getVisibility());
        outState.putString("tvHintText",tvHint.getText().toString());

        outState.putString("lettersUsed", lettersUsed);
        super.onSaveInstanceState(outState);
    }

    private void changeImage(){
        switch (errorCount){
            case 1:
                imageView.setImageResource(R.drawable.p1);
                break;
            case 2:
                imageView.setImageResource(R.drawable.p2);
                break;
            case 3:
                imageView.setImageResource(R.drawable.p3);
                break;
            case 4:
                imageView.setImageResource(R.drawable.p4);
                break;
            case 5:
                imageView.setImageResource(R.drawable.p5);
                break;
            case 6:
                imageView.setImageResource(R.drawable.p6);
                break;

        }
    }

    public void initializedGame(View view){
        // 1. error count.
        errorCount = 0;
        lettersUsed = "";
        hintClicks = 0;
        // 2. answer and textview
        // the following is set answer and textview.
        // TODO need change to random.
        // remember to fit the length!!
        answer = selectRandomWord();
        wordtextView.setText("______");
        // 3. image
        imageView.setImageResource(R.drawable.p0);
        // 4. game result
        gameResult.setVisibility(View.INVISIBLE);
        tvHint.setVisibility(View.INVISIBLE);
        // 5. game state.
        // only onCreate and initialize can change state to true (meaning: start game).
        gameState = true;

    }

    public void getHint(View view){
        // 1. error count.
        hintClicks+=1;
        if(hintClicks > 1 && errorCount+1 >= 6)
            return;
        else if(hintClicks == 1) {
            if(categoriesOfWords.get(0).contains(answer)) {
                tvHint.setText("It is a fruit");
                tvHint.setVisibility(View.VISIBLE);
            }
            else if(categoriesOfWords.get(1).contains(answer)) {
                tvHint.setText("It is a country");
                tvHint.setVisibility(View.VISIBLE);
            }
            else if(categoriesOfWords.get(2).contains(answer)) {
                tvHint.setText("It is a periodic element");
                tvHint.setVisibility(View.VISIBLE);
            }
        }
        else if(hintClicks == 2) {
            String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            char[] alphabetChar = alphabet.toCharArray();
            shuffleArray(alphabetChar);
            int lettersLeft = 26 - lettersUsed.length();
            int lettersToGive = lettersLeft/2;
            int lettersGiven = 0;
            for(int i = 0; i<alphabetChar.length; i++) {
                String letterToCheck = String.valueOf(alphabetChar[i]);
                if(lettersGiven < lettersToGive) {
                    if(!(answer.contains(letterToCheck) || lettersUsed.contains(letterToCheck))) {
                        lettersUsed = lettersUsed + letterToCheck;
                        lettersGiven+=1;
                    }
                }
            }
            errorCount+=1;
            changeImage();
        }
        else if(hintClicks == 3) {
            String vowels = "AEIOUY";
            for(int i = 0; i<vowels.length(); i++) {
                String letterToCheck = String.valueOf(vowels.charAt(i));
                lettersUsed = lettersUsed + letterToCheck;
                if(answer.contains(letterToCheck)) {
                    current = letterToCheck;
                    doJudge(letterToCheck);
                }
            }
            errorCount+=1;
            changeImage();
        }
    }

    private String selectRandomWord() {
        int category = (int) (Math.random()*3);
        int wordIndex = (int) (Math.random()*7);
        String wordToUse = categoriesOfWords.get(category).get(wordIndex);
        return wordToUse;
    }

    private void shuffleArray(char[] array)
    {
        int index;
        char temp;
        Random random = new Random();
        for (int i = array.length - 1; i > 0; i--)
        {
            index = random.nextInt(i + 1);
            temp = array[index];
            array[index] = array[i];
            array[i] = temp;
        }
    }

    private void doJudge(String s){
        // first edition.
        // 1. click and change:
//        wordtextView.setText(s);
        // second edition, check if is in the string, than change string.
        // third edition. based on second one, first check if exists.
        // if not exists: do change image.
        // else: do second condition.
        // forth edition. check if current text view is the answer. if it is, return. Thus done nothing.
        if(!gameState){
            return;
        }
        if(wordtextView.getText().toString().compareTo(answer)==0){
            gameResult.setText(R.string.game_result_win);
            gameResult.setVisibility(View.VISIBLE);
            // 5. gameState: end of the game: false
            gameState = false;
            return;
        }// check if win. even after the game ends with win.
        // Can be optimized using game state bool.

        if (answer.indexOf(current,0)==-1){
            errorCount += 1;
            changeImage();
            if(errorCount>=6){
                // TODO
                // output defeat! like: set textview to visible.
                gameResult.setText(R.string.game_result_lose);
                gameResult.setVisibility(View.VISIBLE);
                gameState = false;
                return;
            }

        }else {
            String currentStr = (String) wordtextView.getText();
            String dupStr = currentStr;
            // need optimized.
            int flag = 0;
            while (answer.indexOf(current, flag) != -1) {
                flag = answer.indexOf(current, flag);
                dupStr = dupStr.substring(0, flag) + current + dupStr.substring(flag + 1);
                flag = flag + 1;
            }
            wordtextView.setText(dupStr);
            if(wordtextView.getText().toString().compareTo(answer)==0){
                gameResult.setText(R.string.game_result_win);
                gameResult.setVisibility(View.VISIBLE);
                gameState = false;
                return;
            }// check game win after the input.
        }

    }
    public void onClick(View view){
        switch (view.getId()){
            case R.id.a:
                if(!lettersUsed.contains("A")) {
                    current = "A";
                    doJudge("A");
                    lettersUsed = lettersUsed + "A";
                }
                break;
            case R.id.b:
                if(!lettersUsed.contains("B")) {
                    current = "B";
                    doJudge("B");
                    lettersUsed = lettersUsed + "B";
                }
                break;
            case R.id.c:
                if(!lettersUsed.contains("C")) {
                    current = "C";
                    doJudge("C");
                    lettersUsed = lettersUsed + "C";
                }
                break;
            case R.id.d:
                if(!lettersUsed.contains("D")) {
                    current = "D";
                    doJudge("D");
                    lettersUsed = lettersUsed + "D";
                }
                break;
            case R.id.e:
                if(!lettersUsed.contains("E")) {
                    current = "E";
                    doJudge("E");
                    lettersUsed = lettersUsed + "E";
                }
                break;
            case R.id.f:
                if(!lettersUsed.contains("F")) {
                    current = "F";
                    doJudge("F");
                    lettersUsed = lettersUsed + "F";
                }
                break;
            case R.id.g:
                if(!lettersUsed.contains("G")) {
                    current = "G";
                    doJudge("G");
                    lettersUsed = lettersUsed + "G";
                }
                break;
            case R.id.h:
                if(!lettersUsed.contains("H")) {
                    current = "H";
                    doJudge("H");
                    lettersUsed = lettersUsed + "H";
                }
                break;
            case R.id.i:
                if(!lettersUsed.contains("I")) {
                    current = "I";
                    doJudge("I");
                    lettersUsed = lettersUsed + "I";
                }
                break;
            case R.id.j:
                if(!lettersUsed.contains("J")) {
                    current = "J";
                    doJudge("J");
                    lettersUsed = lettersUsed + "J";
                }
                break;
            case R.id.k:
                if(!lettersUsed.contains("K")) {
                    current = "K";
                    doJudge("K");
                    lettersUsed = lettersUsed + "K";
                }
                break;
            case R.id.l:
                if(!lettersUsed.contains("L")) {
                    current = "L";
                    doJudge("L");
                    lettersUsed = lettersUsed + "L";
                }
                break;
            case R.id.m:
                if(!lettersUsed.contains("M")) {
                    current = "M";
                    doJudge("M");
                    lettersUsed = lettersUsed + "M";
                }
                break;
            case R.id.n:
                if(!lettersUsed.contains("N")) {
                    current = "N";
                    doJudge("N");
                    lettersUsed = lettersUsed + "N";
                }
                break;
            case R.id.o:
                if(!lettersUsed.contains("O")) {
                    current = "O";
                    doJudge("O");
                    lettersUsed = lettersUsed + "O";
                }
                break;
            case R.id.p:
                if(!lettersUsed.contains("P")) {
                    current = "P";
                    doJudge("P");
                    lettersUsed = lettersUsed + "P";
                }
                break;
            case R.id.q:
                if(!lettersUsed.contains("Q")) {
                    current = "Q";
                    doJudge("Q");
                    lettersUsed = lettersUsed + "Q";
                }
                break;
            case R.id.r:
                if(!lettersUsed.contains("R")) {
                    current = "R";
                    doJudge("R");
                    lettersUsed = lettersUsed + "R";
                }
                break;
            case R.id.s:
                if(!lettersUsed.contains("S")) {
                    current = "S";
                    doJudge("S");
                    lettersUsed = lettersUsed + "S";
                }
                break;
            case R.id.t:
                if(!lettersUsed.contains("T")) {
                    current = "T";
                    doJudge("T");
                    lettersUsed = lettersUsed + "T";
                }
                break;
            case R.id.u:
                if(!lettersUsed.contains("U")) {
                    current = "U";
                    doJudge("U");
                    lettersUsed = lettersUsed + "U";
                }
                break;
            case R.id.v:
                if(!lettersUsed.contains("V")) {
                    current = "V";
                    doJudge("V");
                    lettersUsed = lettersUsed + "V";
                }
                break;
            case R.id.w:
                if(!lettersUsed.contains("W")) {
                    current = "W";
                    doJudge("W");
                    lettersUsed = lettersUsed + "W";
                }
                break;
            case R.id.x:
                if(!lettersUsed.contains("X")) {
                    current = "X";
                    doJudge("X");
                    lettersUsed = lettersUsed + "X";
                }
                break;
            case R.id.y:
                if(!lettersUsed.contains("Y")) {
                    current = "Y";
                    doJudge("Y");
                    lettersUsed = lettersUsed + "Y";
                }
                break;
            case R.id.z:
                if(!lettersUsed.contains("Z")) {
                    current = "Z";
                    doJudge("Z");
                    lettersUsed = lettersUsed + "Z";
                }
                break;
            default:
                break;



        }
    }
}