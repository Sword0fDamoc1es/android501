package com.example.workoutapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private ListView listViewWorkout;
    private String[] workouts = {"Easy", "Medium", "Hard"};
    private SensorManager sensorManager;
    private Sensor sensorAccelerometer;
    private float mAccel; // acceleration apart from gravity
    private float mAccelCurrent; // current acceleration including gravity
    private float mAccelLast;
    private Button btnStart;
    private Button btnEnd;
    private TextView tvNumSteps;
    private int shakeThreshold;
    private int selectedWorkout;
    private boolean workoutInProgress;
    private int currentSteps;
    private long workoutStartTime;

    private CameraManager CamManager;
    private String CamID;
    private MediaPlayer chariotsOfFire;
    private MediaPlayer rockyTheme;
    private MediaPlayer supermanTheme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chariotsOfFire = MediaPlayer.create(MainActivity.this,R.raw.chariots);
        rockyTheme = MediaPlayer.create(MainActivity.this,R.raw.rocky);
        supermanTheme = MediaPlayer.create(MainActivity.this,R.raw.superman);

        listViewWorkout = (ListView) findViewById(R.id.listViewWorkout);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_activated_1, workouts);
        listViewWorkout.setAdapter(adapter);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensorAccelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(this, sensorAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        mAccel = 0.00f;
        mAccelCurrent = SensorManager.GRAVITY_EARTH;
        mAccelLast = SensorManager.GRAVITY_EARTH;

        btnStart = (Button) findViewById(R.id.btnStart);
        btnEnd = (Button) findViewById(R.id.btnEnd);
        tvNumSteps = (TextView) findViewById(R.id.tvNumSteps);
        workoutInProgress = false;
        currentSteps = 0;

        CamManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            CamID = CamManager.getCameraIdList()[0];  //rear camera is at index 0
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

        listViewWorkout.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                if(!workoutInProgress)
                    selectedWorkout = position;
            }
        });

        btnStart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(selectedWorkout == 0)
                    shakeThreshold = 4;
                else if(selectedWorkout == 1)
                    shakeThreshold = 8;
                else if(selectedWorkout == 2)
                    shakeThreshold = 12;
                workoutInProgress = true;
                currentSteps = 0;
                btnStart.setClickable(false);
                workoutStartTime = System.currentTimeMillis();
            }
        });

        btnEnd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                workoutInProgress = false;
                btnStart.setClickable(true);
                if(supermanTheme != null && supermanTheme.isPlaying())
                    supermanTheme.stop();
                if(chariotsOfFire != null && chariotsOfFire.isPlaying())
                    chariotsOfFire.stop();
                if(rockyTheme != null && rockyTheme.isPlaying())
                    rockyTheme.stop();
            }
        });
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            if(workoutInProgress) {
                if(selectedWorkout==0 && currentSteps > 10) {
                    LightOn();
                    LightOff();
                }
                else if(currentSteps > 30) {
                    LightOn();
                    LightOff();
                }
                if(selectedWorkout == 0 && currentSteps > 30)
                    supermanTheme.start();
                else if(selectedWorkout == 1 && currentSteps > 45)
                    chariotsOfFire.start();
                else if(selectedWorkout == 2 && currentSteps > 60)
                    rockyTheme.start();
                float x = sensorEvent.values[0];
                float y = sensorEvent.values[1];
                float z = sensorEvent.values[2];
                mAccelLast = mAccelCurrent;
                mAccelCurrent = (float) Math.sqrt((double) (x * x + y * y + z * z));
                float delta = mAccelCurrent - mAccelLast;
                mAccel = mAccel * 0.9f + delta; // perform low-cut filter
                if (mAccel > shakeThreshold) {
                    currentSteps += 1;
                    tvNumSteps.setText("Number of steps: "+currentSteps);
                    if(currentSteps>99) {
                        long tEnd = System.currentTimeMillis();
                        long tDelta = tEnd - workoutStartTime;
                        double elapsedSeconds = tDelta / 1000.0;
                        Toast toast;
                        if(elapsedSeconds > 120) {
                            toast = Toast.makeText(getApplicationContext(), "Great job, keep practicing to get faster.", Toast.LENGTH_LONG);
                        }
                        else {
                            toast = Toast.makeText(getApplicationContext(), "You are a rockstar.", Toast.LENGTH_LONG);
                        }
                        toast.show();
                        btnStart.setClickable(true);
                        workoutInProgress = false;
                        if(supermanTheme != null && supermanTheme.isPlaying())
                            supermanTheme.stop();
                        if(chariotsOfFire != null && chariotsOfFire.isPlaying())
                            chariotsOfFire.stop();
                        if(rockyTheme != null && rockyTheme.isPlaying())
                            rockyTheme.stop();
                    }
                }
            }
        }
    }

    public void LightOn()
    {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                CamManager.setTorchMode(CamID, true);
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    public void LightOff()
    {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                CamManager.setTorchMode(CamID, false);
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}