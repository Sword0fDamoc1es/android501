package com.example.picturerating;

import android.app.Fragment;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;


public class LeftRightFragment extends Fragment {

    ArrayList<Drawable> drawables;  //keeping track of our drawables
    private int currDrawableIndex;  //keeping track of which drawable is currently displayed.

    //Boiler Plate Stuff.
    private Button btnLeft;
    private Button btnRight;
    private Message mCommunication;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mCommunication = (Message) context;
    }

    public LeftRightFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.leftright_fragment, container, false);

        btnRight = (Button) v.findViewById(R.id.btnRight);
        btnLeft = (Button) v.findViewById(R.id.btnLeft);

        btnLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCommunication.forwardOrBack(-1);
            }
        });

        btnRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCommunication.forwardOrBack(1);
            }
        });

        return v;
    }

    public interface Message {
        void forwardOrBack(int forwardOrBack);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mCommunication = null;
    }

}
