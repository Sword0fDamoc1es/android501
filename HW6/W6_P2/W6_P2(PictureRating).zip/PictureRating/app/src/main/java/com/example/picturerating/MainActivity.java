package com.example.picturerating;

import androidx.appcompat.app.AppCompatActivity;

import android.app.FragmentManager;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements LeftRightFragment.Message {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @Override
    public void forwardOrBack(int forwardOrBack) {
        FragmentManager manager = getFragmentManager();
        PictureAndRatingFragment mReceiverFragment = (PictureAndRatingFragment) manager.findFragmentById(R.id.pictureRatingFragment);
        mReceiverFragment.forwardOrBack(forwardOrBack);
    }
}