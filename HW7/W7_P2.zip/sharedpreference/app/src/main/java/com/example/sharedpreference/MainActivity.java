package com.example.sharedpreference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    public Button button;
    public ImageView iv;
    public EditText editText;
    public ArrayList<Integer> pictureID;
    public int pointer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv = (ImageView) findViewById(R.id.imageView);
        editText = (EditText) findViewById(R.id.editText);
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref",MODE_PRIVATE);
        if(sharedPreferences.getInt("picID",0)!=0){
            iv.setImageResource(sharedPreferences.getInt("picID",0));
            editText.setText(sharedPreferences.getString("str",""));
            pointer = sharedPreferences.getInt("picID",0);
        }else{
            iv.setImageResource(R.drawable.chim);
        }
        button = (Button) findViewById(R.id.button);

        pictureID = new ArrayList<>();
        pictureID.add(R.drawable.chim);
        pictureID.add(R.drawable.cow);
        pictureID.add(R.drawable.dog);
        pictureID.add(R.drawable.lion);
        pictureID.add(R.drawable.rooster);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random rand = new Random();
                int i = rand.nextInt(pictureID.size());
                iv.setImageResource(pictureID.get(i));
                pointer = pictureID.get(i);
                SharedPreferences.Editor edit = sharedPreferences.edit();
                edit.putInt("picID",pictureID.get(i));
                edit.putString("str",editText.getText().toString());
                edit.commit();
            }
        });
    }

    @Override
    protected void onPause() {
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref",MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();

        // write all the data entered by the user in SharedPreference and apply
        myEdit.putString("str", editText.getText().toString());
        myEdit.putInt("picID", pointer);
        myEdit.apply();
        super.onPause();

    }
}