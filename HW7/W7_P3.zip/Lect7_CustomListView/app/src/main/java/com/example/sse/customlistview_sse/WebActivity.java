package com.example.sse.customlistview_sse;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.TextView;

public class WebActivity extends AppCompatActivity {
    private TextView tvTitle;
    private WebView wvWebpage;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webpage);
        Bundle extras = getIntent().getExtras();
        String title = extras.getString("episodeTitle");
        String episodes[] = getResources().getStringArray(R.array.episodes);

        tvTitle = (TextView) findViewById(R.id.tvTitle);
        wvWebpage = (WebView) findViewById(R.id.wvWebpage);

        String url = "http://www.google.com/";
        if (title.equals(episodes[0])) url = "https://www.imdb.com/title/tt0708449/";
        if (title.equals(episodes[1])) url = "https://www.imdb.com/title/tt0708418/";
        if (title.equals(episodes[2])) url = "https://www.imdb.com/title/tt0708483/";
        if (title.equals(episodes[3])) url = "https://www.imdb.com/title/tt0708438/";
        if (title.equals(episodes[4])) url = "https://www.imdb.com/title/tt0708443/";
        if (title.equals(episodes[5])) url = "https://www.imdb.com/title/tt0708473/";
        if (title.equals(episodes[6])) url = "https://www.imdb.com/title/tt0708480/";

        tvTitle.setText(title);
        wvWebpage.loadUrl(url);
    }
}
