package com.example.meet4sho.api;

public class TMEventSales {
    private String currency;
    private String price_min;
    private String price_max;
}
