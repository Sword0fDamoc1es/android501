package com.example.meet4sho;

import com.example.meet4sho.model.APIresponse;

public interface Movie_onFetchListener {
    void onFetchData(APIresponse apiresponse, String message);
    void onError(String message);
}
