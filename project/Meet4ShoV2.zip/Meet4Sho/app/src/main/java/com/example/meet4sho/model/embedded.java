package com.example.meet4sho.model;

import java.util.List;

public class embedded {
    List<suggestions> suggestions = null;

    public List<com.example.meet4sho.model.suggestions> getSuggestions() {
        return suggestions;
    }

    public void setSuggestions(List<com.example.meet4sho.model.suggestions> suggestions) {
        this.suggestions = suggestions;
    }
}
