package com.example.meet4sho.model;

public class links {
    self self = null;

    public com.example.meet4sho.model.self getSelf() {
        return self;
    }

    public void setSelf(com.example.meet4sho.model.self self) {
        this.self = self;
    }
}
