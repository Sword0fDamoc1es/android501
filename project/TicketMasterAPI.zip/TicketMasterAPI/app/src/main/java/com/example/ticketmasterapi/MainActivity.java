package com.example.ticketmasterapi;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ticketmaster.api.discovery.DiscoveryApi;
import com.ticketmaster.api.discovery.operation.SearchEventsOperation;
import com.ticketmaster.api.discovery.response.PagedResponse;
import com.ticketmaster.discovery.model.Event;
import com.ticketmaster.discovery.model.Events;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.commons.io.IOUtil;

public class MainActivity extends AppCompatActivity {
    // views
    private EditText etCity, etPostalCode, etKeyword;
    private Button btSubmit;
    private TextView tvSearchResult;

    // constants
    private final String TM_API_KEY = "PqFUIagPA9p1AMWB2SeEF9QFyhGnG0P7";
    private final String LOG_TAG = "[MainActivity]";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        // load properties (doesn't work)
//        Properties prop = new Properties();
//        InputStream gradleProp = null;
//        try {
//            gradleProp = new FileInputStream("/gradle.properties");
//            prop.load(gradleProp);
//            TM_API_KEY = prop.getProperty("tm_api_key");
//            Toast.makeText(this, TM_API_KEY, Toast.LENGTH_SHORT).show();
//            System.out.println("TM_API_KEY = " + TM_API_KEY);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        // init views
        etCity = (EditText) findViewById(R.id.etCity);
        etPostalCode = (EditText) findViewById(R.id.etPostalCode);
        etKeyword = (EditText) findViewById(R.id.etKeyword);
        btSubmit = (Button) findViewById(R.id.btSubmit);
        tvSearchResult = (TextView) findViewById(R.id.tvSearchResult);

        // view actions
        btSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String city = etCity.getText().toString();
                String postalCode = etPostalCode.getText().toString();
                String keyword = etKeyword.getText().toString();
                new TicketMaster().execute(city, postalCode, keyword);
            }
        });
    }

    private class TicketMaster extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params) {
            String city = params[0];
            String postalCode = params[1];
            String keyword = params[2];
            String page = Integer.toString(1);
            String size = Integer.toString(1);
            String url_formatted = String.format("https://app.ticketmaster.com/discovery/v2/events.json?keyword=%s&city=%s&size=%s&postalCode=%s&page=%s&apikey=%s",keyword,city,size,postalCode,page,TM_API_KEY);
            Log.i(LOG_TAG, "Formatted URL: " + url_formatted);
            URL url = null;
            HttpURLConnection urlConnection = null;
            String responseString = null;
            try {
                url = new URL(url_formatted);
                urlConnection = (HttpURLConnection) url.openConnection();
                Log.i(LOG_TAG, urlConnection.getContentType());
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                responseString = IOUtil.toString(in);
                // TODO: parse json object
//                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
//                StringBuilder response = new StringBuilder();
//                JsonObject jsonObject = new JsonParser().parse(reader).getAsJsonObject();
//                Log.i(LOG_TAG, "JSON Object:\n" + jsonObject);
//                jsonObject.get("events").getAsJsonObject();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                urlConnection.disconnect();
            }
            return responseString;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            tvSearchResult.setText(result);
        }
    }
}