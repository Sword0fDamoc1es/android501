package com.example.fandango0.model;

import java.util.List;

public class embedded {
    List<suggestions> suggestions = null;

    public List<com.example.fandango0.model.suggestions> getSuggestions() {
        return suggestions;
    }

    public void setSuggestions(List<com.example.fandango0.model.suggestions> suggestions) {
        this.suggestions = suggestions;
    }
}
