package com.example.fandango0;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.os.AsyncTask;
import android.util.Log;

import org.apache.commons.io.IOUtil;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.*;
import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    public Button btnLeft;
    public Button btnRight;
    public TextView tvOne;
    public TextView tvTwo;
    public TextView tvThree;
    public TextView tvFour;
    public TextView tvFive;
    public TextView tvSix;
    public TextView tvSeven;
    public TextView tvEight;
    public ArrayList<TextView> textViews = new ArrayList<>();
////    public String zip = "?query=town center";
////    public String zip = "66062"
//    public String country_abbrev = "US";
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        button = findViewById(R.id.button);
//        textView = findViewById(R.id.textView);
//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                ResponseManager mg = new ResponseManager(MainActivity.this);
//                mg.getReplyByZip(listener,country_abbrev);
//            }
//        });
//    }
    private TextView tvSearchResult;
    // marve's key
    private String API_KEY = "c5a45837e9632229e51e8455548838d7";
    private List<String> ids = new ArrayList<>();
    private List<String> movieDescriptions = new ArrayList<>();
    private List<String> moviePosterURLs = new ArrayList<>();
    private int startingIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvOne = (TextView) findViewById(R.id.tvOne);
        textViews.add(tvOne);
        tvTwo = (TextView) findViewById(R.id.tvTwo);
        textViews.add(tvTwo);
        tvThree = (TextView) findViewById(R.id.tvThree);
        textViews.add(tvThree);
        tvFour = (TextView) findViewById(R.id.tvFour);
        textViews.add(tvFour);
        tvFive = (TextView) findViewById(R.id.tvFive);
        textViews.add(tvFive);
        tvSix = (TextView) findViewById(R.id.tvSix);
        textViews.add(tvSix);
        tvSeven = (TextView) findViewById(R.id.tvSeven);
        textViews.add(tvSeven);
        tvEight = (TextView) findViewById(R.id.tvEight);
        textViews.add(tvEight);

        btnLeft = (Button) findViewById(R.id.btnLeft);
        btnRight = (Button) findViewById(R.id.btnRight);

        new TMDBService().execute();

        btnLeft.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (startingIndex == 0) ;
                else {
                    if (startingIndex - 8 < 0)
                        startingIndex = 0;
                    else
                        startingIndex -= 8;
                }
                new TMDBService().execute();
            }
        });

        btnRight.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (startingIndex + 8 > ids.size() - 8)
                    startingIndex = ids.size() - 8;
                else
                    startingIndex += 8;
                new TMDBService().execute();
            }
        });
    }

    public void onClick(View view){
        Intent i = new Intent(getApplicationContext(),MovieInfoActivity.class);
        switch (view.getId()){
            case R.id.tvOne:
                i.putExtra("movieDescription",movieDescriptions.get(0));
                i.putExtra("moviePoster",moviePosterURLs.get(0));
                break;
            case R.id.tvTwo:
                i.putExtra("movieDescription",movieDescriptions.get(1));
                i.putExtra("moviePoster",moviePosterURLs.get(1));
                break;
            case R.id.tvThree:
                i.putExtra("movieDescription",movieDescriptions.get(2));
                i.putExtra("moviePoster",moviePosterURLs.get(2));
                break;
            case R.id.tvFour:
                i.putExtra("movieDescription",movieDescriptions.get(3));
                i.putExtra("moviePoster",moviePosterURLs.get(3));
                break;
            case R.id.tvFive:
                i.putExtra("movieDescription",movieDescriptions.get(4));
                i.putExtra("moviePoster",moviePosterURLs.get(4));
                break;
            case R.id.tvSix:
                i.putExtra("movieDescription",movieDescriptions.get(5));
                i.putExtra("moviePoster",moviePosterURLs.get(5));
                break;
            case R.id.tvSeven:
                i.putExtra("movieDescription",movieDescriptions.get(6));
                i.putExtra("moviePoster",moviePosterURLs.get(6));
                break;
            case R.id.tvEight:
                i.putExtra("movieDescription",movieDescriptions.get(7));
                i.putExtra("moviePoster",moviePosterURLs.get(7));
                break;
            default:
                return;
        }
        startActivity(i);
    }



    private class TMDBService extends AsyncTask<String, String, String>{

        public TMDBService() {
            ids = new ArrayList<>();
            movieDescriptions = new ArrayList<>();
            moviePosterURLs = new ArrayList<>();
        }

        @Override
        protected String doInBackground(String... params) {
            String url_formatted = String.format("https://api.themoviedb.org/3/movie/%s?api_key=%s","popular",API_KEY);
            URL url = null;
            HttpURLConnection urlConnection = null;
            String responseString = null;
            try {
                url = new URL(url_formatted);
                urlConnection = (HttpURLConnection) url.openConnection();
                // the word : popular is the search keyword.
                // change it using other keyword for other functions.
                urlConnection.setRequestProperty("Authorization", "Bearer " + API_KEY);
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                responseString = IOUtil.toString(in);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                urlConnection.disconnect();
            }
            return responseString;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            //tvSearchResult.setText(result);
            Log.i("API RESPONSE:", result);
            JSONObject jsonObj = null;
            try {
                jsonObj = new JSONObject(result);
                if (jsonObj != null) {
                    JSONArray jsonArray_results = jsonObj.getJSONArray("results");
                    for (int i=0; i < jsonArray_results.length(); i++) {
                        ids.add(jsonArray_results.getJSONObject(i).getString("id"));
                    }
//                    tvSearchResult.setText(ids);
                }
                for (int i = 0; i < textViews.size(); i++) {
                    new TMDBResultsDetailAPI(textViews.get(i),i+startingIndex).execute();
                }
//                new TMDBResultsDetailAPI(tvTwo,0).execute();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        private class TMDBResultsDetailAPI extends AsyncTask<String, String, String> {
            TextView toChange;
            int index = 0;

            public TMDBResultsDetailAPI(TextView temp, int loc){
                toChange = temp;
                index = loc;
            }
            @Override
            protected String doInBackground(String... strings) {
                String url_formatted = String.format("https://api.themoviedb.org/3/movie/%s?api_key=c5a45837e9632229e51e8455548838d7",ids.get(index));
                URL url = null;
                HttpURLConnection urlConnection = null;
                String responseString = null;
                try {
                    url = new URL(url_formatted);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestProperty("Authorization", "Bearer " + API_KEY);
                    InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                    responseString = IOUtil.toString(in);
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    urlConnection.disconnect();
                }
                return responseString;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                JSONObject jsonObj = null;
                try {
                    jsonObj = new JSONObject(s);
                    if (jsonObj != null) {
                        String id = jsonObj.getString("id");
                        String original_title = jsonObj.getString("original_title");
                        String popularity = jsonObj.getString("popularity");
                        String release_date = jsonObj.getString("release_date");
                        String tvDisplay = String.format("Title:%s\nPopularity:%s\nRelease Date:%s", original_title,popularity,release_date);
                        toChange.setText(tvDisplay);
                        movieDescriptions.add(jsonObj.getString("overview"));
                        moviePosterURLs.add(jsonObj.getString("poster_path"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
//    private final onFetchListener listener = new onFetchListener() {
//        @Override
//        public void onFetchData(APIresponse apiresponse, String message) {
//            if(apiresponse == null){
//                Toast.makeText(MainActivity.this,"nothing",Toast.LENGTH_SHORT).show();
//                return;
//            }
//            showData(apiresponse);
//        }
//
//        @Override
//        public void onError(String message) {
//
//        }
//    };
//    private void showData(APIresponse apiresponse){
//        textView.setText("count: " + apiresponse.getCount());
//    }
}