package com.example.fandango0;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MovieInfoActivity extends AppCompatActivity {

    public ImageView ivPoster;
    public TextView tvDescription;

    private String imgURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_info);

        Bundle extras = getIntent().getExtras();

        String description = extras.getString("movieDescription");
        imgURL = extras.getString("moviePoster");

        ivPoster = (ImageView) findViewById(R.id.ivPoster);
        tvDescription = (TextView) findViewById(R.id.tvDescription);

        tvDescription.setText(description);

        try {
            val `in` = java.net.URL(imageURL).openStream()
            image = BitmapFactory.decodeStream(`in`)

            // Only for making changes in UI
            handler.post {
                imageView.setImageBitmap(image)
            }
    }

}
