package com.example.fandango0;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.InputStream;
import java.net.URL;

public class MovieInfoActivity extends AppCompatActivity {

    /***
     * ivPoster: ImageView that displays the movie poster
     * tvDescription: TextView that displays the movie's description
     * btnBack: A button that allows for the user to go back to the start up page
     * imgURL: The URL to the movie's poster that is passed in from MainActivity
     */
    public ImageView ivPoster;
    public TextView tvDescription;
    public Button btnBack;

    private String imgURL;

    /**
     * 1.) Retrieve the movie description and movie poster URL from the intent extras
     * 2.) Set up the ImageView, TextView, and Button
     * 3.) Set up Button so that when it's clicked the user is taken back to the start page
     * 4.) Set the TextView to the movie description that was passed in
     * 5.) Execute a DownloadImageTask with the base TMDB URL plus the movie poster URL that was passed in
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_info);

        Bundle extras = getIntent().getExtras();

        String description = extras.getString("movieDescription");
        imgURL = extras.getString("moviePoster");

        ivPoster = (ImageView) findViewById(R.id.ivPoster);
        tvDescription = (TextView) findViewById(R.id.tvDescription);
        btnBack = (Button) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
            }
        });

        tvDescription.setText(description);
        new DownloadImageTask(ivPoster).execute("https://image.tmdb.org/t/p/w500"+imgURL);
    }

    /**
     * 1.) Retrieve the movie poster from the URL as an InputStream
     * 2.) Use a BitmapFactory to decode the InputStream
     * 3.) Set ImageView to the Bitmap
     */
    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }

}
