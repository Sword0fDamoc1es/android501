package com.example.fandango0.model;

public class links {
    self self = null;

    public com.example.fandango0.model.self getSelf() {
        return self;
    }

    public void setSelf(com.example.fandango0.model.self self) {
        this.self = self;
    }
}
